import React from 'react';
import { ArrowRight } from 'lucide-react';

const Hero: React.FC = () => {
  return (
    <section id="hero" className="relative h-screen flex items-center justify-center overflow-hidden">
      {/* Background with overlay */}
      <div 
        className="absolute inset-0 z-0 parallax" 
        style={{
            backgroundImage: 'url("https://picsum.photos/id/431/1920/1080")',
            filter: 'brightness(0.6)'
        }}
      ></div>

      <div className="relative z-10 text-center px-4 sm:px-6 lg:px-8 max-w-4xl mx-auto">
        <h1 className="font-serif text-5xl md:text-7xl lg:text-8xl text-white font-bold mb-6 tracking-wide drop-shadow-lg">
          Brew Haven
        </h1>
        <p className="text-xl md:text-2xl text-coffee-100 mb-10 font-light max-w-2xl mx-auto drop-shadow-md">
          Crafting moments of joy, one cup at a time. Experience the finest beans roasted to perfection.
        </p>
        <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
          <a
            href="#menu"
            className="group bg-coffee-500 hover:bg-coffee-600 text-white px-8 py-4 rounded-full text-lg font-semibold transition-all duration-300 shadow-lg hover:shadow-xl hover:-translate-y-1 flex items-center"
          >
            Order Coffee
            <ArrowRight className="ml-2 group-hover:translate-x-1 transition-transform" size={20} />
          </a>
          <a
            href="#about"
            className="bg-white/10 hover:bg-white/20 backdrop-blur-sm text-white border border-white/30 px-8 py-4 rounded-full text-lg font-semibold transition-all duration-300 flex items-center"
          >
            Explore Menu
          </a>
        </div>
      </div>
    </section>
  );
};

export default Hero;
