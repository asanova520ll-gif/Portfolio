import React, { useState } from 'react';
import { CONTACT_INFO } from '../constants';
import { MapPin, Phone, Mail, Clock } from 'lucide-react';

const Contact: React.FC = () => {
  const [formStatus, setFormStatus] = useState<'idle' | 'success'>('idle');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Simulate form submission
    setFormStatus('success');
    setTimeout(() => setFormStatus('idle'), 3000);
  };

  return (
    <section id="contact" className="py-24 bg-coffee-900 text-coffee-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16">
          
          {/* Contact Info */}
          <div>
            <span className="text-orange-400 font-semibold tracking-wider uppercase text-sm">Get in Touch</span>
            <h2 className="font-serif text-4xl md:text-5xl font-bold mt-2 mb-8">Visit Us Today</h2>
            <p className="text-coffee-200 mb-12 text-lg">
              We'd love to see you. Drop by for a cup, or send us a message if you have any questions or feedback.
            </p>

            <div className="space-y-8">
              <div className="flex items-start space-x-6">
                <div className="bg-coffee-800 p-4 rounded-full text-orange-400">
                  <MapPin size={24} />
                </div>
                <div>
                  <h3 className="text-xl font-bold mb-1">Our Location</h3>
                  <p className="text-coffee-200">{CONTACT_INFO.address}</p>
                </div>
              </div>

              <div className="flex items-start space-x-6">
                <div className="bg-coffee-800 p-4 rounded-full text-orange-400">
                  <Phone size={24} />
                </div>
                <div>
                  <h3 className="text-xl font-bold mb-1">Phone Number</h3>
                  <p className="text-coffee-200">{CONTACT_INFO.phone}</p>
                </div>
              </div>

              <div className="flex items-start space-x-6">
                 <div className="bg-coffee-800 p-4 rounded-full text-orange-400">
                  <Clock size={24} />
                </div>
                <div>
                  <h3 className="text-xl font-bold mb-1">Opening Hours</h3>
                  <p className="text-coffee-200">{CONTACT_INFO.hours}</p>
                </div>
              </div>
            </div>
          </div>

          {/* Form & Map */}
          <div className="bg-white rounded-3xl p-8 md:p-10 shadow-2xl text-coffee-900">
            <h3 className="font-serif text-2xl font-bold mb-6">Send us a message</h3>
            
            <form onSubmit={handleSubmit} className="space-y-6">
              <div>
                <label htmlFor="name" className="block text-sm font-medium text-coffee-700 mb-1">Your Name</label>
                <input 
                  type="text" 
                  id="name"
                  required
                  className="w-full px-4 py-3 rounded-lg bg-coffee-50 border border-coffee-200 focus:outline-none focus:ring-2 focus:ring-coffee-500 transition-shadow"
                  placeholder="John Doe"
                />
              </div>
              
              <div>
                <label htmlFor="phone" className="block text-sm font-medium text-coffee-700 mb-1">Phone Number</label>
                <input 
                  type="tel" 
                  id="phone"
                  className="w-full px-4 py-3 rounded-lg bg-coffee-50 border border-coffee-200 focus:outline-none focus:ring-2 focus:ring-coffee-500 transition-shadow"
                  placeholder="(555) 000-0000"
                />
              </div>

              <div>
                <label htmlFor="message" className="block text-sm font-medium text-coffee-700 mb-1">Message</label>
                <textarea 
                  id="message"
                  required
                  rows={4}
                  className="w-full px-4 py-3 rounded-lg bg-coffee-50 border border-coffee-200 focus:outline-none focus:ring-2 focus:ring-coffee-500 transition-shadow"
                  placeholder="Tell us what you think..."
                ></textarea>
              </div>

              <button 
                type="submit"
                className="w-full bg-coffee-600 hover:bg-coffee-700 text-white font-bold py-4 rounded-lg transition-colors duration-200 shadow-md"
              >
                {formStatus === 'success' ? 'Message Sent!' : 'Send Message'}
              </button>
            </form>

            <div className="mt-8 rounded-xl overflow-hidden h-48 bg-coffee-100 relative">
               {/* Visual Map Placeholder */}
               <div className="absolute inset-0 flex items-center justify-center bg-coffee-200/50">
                  <span className="text-coffee-600 font-medium flex items-center">
                    <MapPin className="mr-2" size={20} />
                    Map Embedded Here
                  </span>
               </div>
               {/* In a real app, an iframe would go here */}
            </div>
          </div>

        </div>
      </div>
    </section>
  );
};

export default Contact;
