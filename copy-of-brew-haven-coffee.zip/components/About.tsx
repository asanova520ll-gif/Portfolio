import React from 'react';
import { Award, Heart, Bean } from 'lucide-react';

const About: React.FC = () => {
  const features = [
    { icon: <Bean className="text-coffee-600" size={24} />, text: "Ethically sourced beans from premium growers." },
    { icon: <Award className="text-coffee-600" size={24} />, text: "Award-winning baristas passionate about craft." },
    { icon: <Heart className="text-coffee-600" size={24} />, text: "Roasted locally in small batches daily." },
  ];

  return (
    <section id="about" className="py-24 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
          
          <div className="relative group">
            <div className="absolute -inset-4 bg-coffee-200 rounded-2xl rotate-2 group-hover:rotate-1 transition-transform duration-300 opacity-50"></div>
            <img 
              src="https://picsum.photos/id/800/600/600" 
              alt="Barista pouring latte art" 
              className="relative rounded-2xl shadow-2xl w-full object-cover h-[500px]"
            />
          </div>

          <div>
            <span className="text-coffee-600 font-semibold tracking-wider uppercase text-sm">About Us</span>
            <h2 className="font-serif text-4xl md:text-5xl font-bold text-coffee-900 mt-2 mb-6">
              Serving quality coffee since 2020.
            </h2>
            <p className="text-lg text-coffee-700/80 leading-relaxed mb-8">
              At Brew Haven, we believe coffee is more than just a drink—it's a ritual. 
              Founded in the heart of the city, we started with a simple mission: to bring people 
              together over the perfect cup. Our space is designed for connection, creativity, and comfort.
            </p>

            <ul className="space-y-6">
              {features.map((feature, idx) => (
                <li key={idx} className="flex items-center space-x-4">
                  <div className="bg-coffee-100 p-3 rounded-full flex-shrink-0">
                    {feature.icon}
                  </div>
                  <span className="text-lg text-coffee-800 font-medium">{feature.text}</span>
                </li>
              ))}
            </ul>
          </div>
        </div>
      </div>
    </section>
  );
};

export default About;
