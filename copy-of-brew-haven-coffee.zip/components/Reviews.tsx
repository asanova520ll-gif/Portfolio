import React from 'react';
import { REVIEWS } from '../constants';
import { Star } from 'lucide-react';

const Reviews: React.FC = () => {
  return (
    <section id="reviews" className="py-24 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
           <span className="text-coffee-600 font-semibold tracking-wider uppercase text-sm">Testimonials</span>
           <h2 className="font-serif text-4xl md:text-5xl font-bold text-coffee-900 mt-2">What Our Customers Say</h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {REVIEWS.map((review) => (
            <div key={review.id} className="bg-coffee-50 p-8 rounded-2xl relative border border-coffee-100 shadow-sm hover:shadow-md transition-shadow">
              <div className="flex items-center space-x-1 mb-6">
                {[...Array(review.rating)].map((_, i) => (
                  <Star key={i} size={18} className="fill-orange-400 text-orange-400" />
                ))}
              </div>
              <p className="text-coffee-800 text-lg italic mb-6 leading-relaxed">"{review.text}"</p>
              <div className="flex items-center space-x-4">
                <img 
                  src={review.avatar} 
                  alt={review.name} 
                  className="w-12 h-12 rounded-full object-cover border-2 border-white shadow-sm"
                />
                <div>
                  <h4 className="font-bold text-coffee-900">{review.name}</h4>
                  <span className="text-xs text-coffee-500 uppercase tracking-wide">Verified Customer</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Reviews;
