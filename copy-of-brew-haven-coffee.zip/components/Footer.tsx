import React from 'react';
import { Facebook, Instagram, Twitter, Heart } from 'lucide-react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-coffee-950 text-coffee-200/80 py-12 border-t border-coffee-900">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row justify-between items-center">
          
          <div className="mb-6 md:mb-0">
            <span className="font-serif text-2xl font-bold text-white tracking-tight block text-center md:text-left">Brew Haven</span>
            <p className="text-sm mt-2">© {new Date().getFullYear()} Brew Haven. All rights reserved.</p>
          </div>

          <div className="flex space-x-6 mb-6 md:mb-0">
            <a href="#" className="hover:text-white transition-colors"><Instagram size={24} /></a>
            <a href="#" className="hover:text-white transition-colors"><Facebook size={24} /></a>
            <a href="#" className="hover:text-white transition-colors"><Twitter size={24} /></a>
          </div>

          <div className="flex items-center text-sm">
            <span>Made with</span>
            <Heart size={16} className="mx-1 text-red-500 fill-red-500" />
            <span>and lots of coffee.</span>
          </div>

        </div>
      </div>
    </footer>
  );
};

export default Footer;
