import { GoogleGenAI } from "@google/genai";
import { MENU_ITEMS } from '../constants';

const apiKey = process.env.API_KEY;
let ai: GoogleGenAI | null = null;

if (apiKey) {
  ai = new GoogleGenAI({ apiKey });
}

export const getBaristaRecommendation = async (userPreference: string): Promise<string> => {
  if (!ai) {
    return "I'm sorry, I seem to be having trouble connecting to my brain right now. Please try again later!";
  }

  const menuContext = MENU_ITEMS.map(item => `${item.name} (${item.category}): ${item.description}`).join('\n');

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `You are a friendly, knowledgeable barista at "Brew Haven".
      
      Here is our menu:
      ${menuContext}
      
      The customer says: "${userPreference}"
      
      Recommend 1 item from the menu that matches their preference. Explain why in 1 short sentence. Be enthusiastic and cozy.
      Do not mention items not on the menu.`,
    });

    return response.text || "I'd recommend the Classic Espresso. You can't go wrong with a classic!";
  } catch (error) {
    console.error("Gemini API Error:", error);
    return "I'd recommend our daily special! (I'm having a little trouble thinking right now).";
  }
};
