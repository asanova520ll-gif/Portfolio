import { MenuItem, Review } from './types';

export const MENU_ITEMS: MenuItem[] = [
  {
    id: '1',
    name: 'Classic Espresso',
    price: '$3.50',
    description: 'Rich, bold, and perfectly extracted double shot.',
    image: 'https://picsum.photos/id/425/400/400',
    category: 'drink'
  },
  {
    id: '2',
    name: 'Caramel Latte',
    price: '$5.50',
    description: 'Silky steamed milk with vanilla syrup and caramel drizzle.',
    image: 'https://picsum.photos/id/63/400/400',
    category: 'drink'
  },
  {
    id: '3',
    name: 'Cold Brew Delight',
    price: '$4.75',
    description: 'Steeped for 24 hours, smooth and low acidity.',
    image: 'https://picsum.photos/id/1060/400/400',
    category: 'drink'
  },
  {
    id: '4',
    name: 'Blueberry Scone',
    price: '$3.75',
    description: 'Freshly baked daily with real blueberries.',
    image: 'https://picsum.photos/id/493/400/400',
    category: 'dessert'
  },
  {
    id: '5',
    name: 'Matcha Green Tea',
    price: '$5.00',
    description: 'Premium ceremonial grade matcha with oat milk.',
    image: 'https://picsum.photos/id/225/400/400',
    category: 'drink'
  }
];

export const REVIEWS: Review[] = [
  {
    id: '1',
    name: 'Sarah Johnson',
    avatar: 'https://picsum.photos/id/64/100/100',
    text: "The best atmosphere in the city. Their cold brew is an absolute lifesaver on busy mornings!",
    rating: 5
  },
  {
    id: '2',
    name: 'Michael Chen',
    avatar: 'https://picsum.photos/id/91/100/100',
    text: "Staff is incredibly friendly and the Wi-Fi is fast. A perfect spot for freelancers.",
    rating: 5
  },
  {
    id: '3',
    name: 'Jessica Davis',
    avatar: 'https://picsum.photos/id/129/100/100',
    text: "I love their blueberry scones. Always fresh and warm. Highly recommended!",
    rating: 4
  }
];

export const CONTACT_INFO = {
  address: "123 Brew Avenue, Coffee City, CA 90210",
  phone: "+1 (555) 123-4567",
  email: "hello@brewhaven.com",
  hours: "Mon-Sun: 7am - 8pm"
};
